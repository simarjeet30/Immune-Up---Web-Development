<?php

session_start();

$conn = mysqli_connect('localhost:3307','priyam','123456','cowin');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_destroy();
header("Location:website1.php");

?>